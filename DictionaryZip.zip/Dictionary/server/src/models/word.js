import mongoose from "mongoose";


const wordSchema = mongoose.Schema({
    word:{
        type:String,
        min:6,
        max:32,
        required:true,
    },
    meaning:{
        type:String,
        min:6,
        max:32,
        required:true,
    },

    type:{
        type:String,
        min:6,
        max:32,
    },
    

    
})

export default mongoose.model("Word",wordSchema)