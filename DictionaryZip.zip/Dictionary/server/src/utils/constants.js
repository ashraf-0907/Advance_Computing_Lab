export const StatusCode={
    SUCCESS:200,
    VALIDATION_ERROR:201,
    UNPROCESSABLE_ENTRY:202,
}

export const JWT_TOKEN_SECRET="sdjfsdjfssdjgsdakfjas;fj";

export const DB_CONNECT="mongodb+srv://ashrafkhan:ashraf12345@todolist.va2cvqx.mongodb.net/Dictionary";