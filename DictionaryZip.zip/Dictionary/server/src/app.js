import express from "express";
import mongoose from "mongoose";
import apiRoutes from "./routes/api.js";
import cors from 'cors'
import { DB_CONNECT } from "./utils/constants.js";

const app = express();

mongoose.connect(DB_CONNECT,{useNewUrlParser:true},(err) => console.log(err));
mongoose.set('strictQuery',false);

const PORT = 3000;

app.use(cors());

app.use(express.json());
app.use('/api/',apiRoutes);

app.listen(PORT,()=>console.log("server is running"));