import express from "express";
import Register from "../controllers/RegisterWord.controller.js";
import { RemoveWord } from "../controllers/RemoveWord.controller.js";
import Search from "../controllers/SearchWord.controller.js";
import Update from "../controllers/UpdateWord.controller.js";
import { GetWords } from "../controllers/WordList.controller.js";


const apiRoutes=express.Router();

apiRoutes.post('/addWord',Register);
apiRoutes.post('/delete',RemoveWord);
apiRoutes.post('/update',Update);
apiRoutes.post('/home',Search);

export default apiRoutes;