
import { StatusCode } from "../utils/constants.js";
import { jsonGenerate } from "../utils/helper.js";
import Word from "../models/word.js"


const Register = async (req, res) =>{
    // const error=validationResult(req);
    const {word , meaning } = req.body;
    const existWord =await Word.findOne({word:word});

    if(!existWord)
    {
        try {
            const result= await Word.create({
                word:word,
                meaning:meaning,
            })
            res.json(jsonGenerate(StatusCode.SUCCESS,"Word Added Successfully",result))
        } catch (error) {
            console.log(error);
        }
        return ;
    }
    else{
        console.log("executed")
        res.json(jsonGenerate(StatusCode.UNPROCESSABLE_ENTRY,"Already Exist",null));
        return;
    }

    
}

export default Register;