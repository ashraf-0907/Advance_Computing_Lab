import Word from "../models/word.js"
import { StatusCode } from "../utils/constants.js";
import { jsonGenerate } from "../utils/helper.js";

export  const RemoveWord = async (req,res) =>{
    const word = req.body;
   // console.log(word);
    const rep=await await Word.findOne(word)
    //console.log(rep);
    if(!rep)
    {
        return res.send(jsonGenerate(StatusCode.VALIDATION_ERROR,"Word not found",null));
    }
    else{
       try {
        const result = await Word.deleteOne(rep._id);
        return res.json(jsonGenerate(StatusCode.SUCCESS,"Found and deleted",null));
       } catch (error) {
        return res.json(jsonGenerate(StatusCode.UNPROCESSABLE_ENTRY,"Word cannot be deleted",null));
       }
    }
}