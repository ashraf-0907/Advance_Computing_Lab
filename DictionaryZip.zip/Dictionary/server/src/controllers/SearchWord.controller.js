import { StatusCode } from "../utils/constants.js";
import { jsonGenerate } from "../utils/helper.js";
import Word from "../models/word.js"


const Search = async (req, res) =>{
    // const error=validationResult(req);
    const {word } = req.body;
    console.log(word)
        try {
            const existWord =await Word.findOne({word:word});
            if(existWord){
            res.json(jsonGenerate(StatusCode.SUCCESS,"Search Successfull",existWord))}
            else
            {
                res.json(jsonGenerate(StatusCode.UNPROCESSABLE_ENTRY,"Word does Not exist",null));
            }
        } catch (error) {
            console.log(error);
        }
}

export default Search;