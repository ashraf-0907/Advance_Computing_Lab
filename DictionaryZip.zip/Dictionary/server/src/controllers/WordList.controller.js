import { StatusCode } from "../utils/constants.js";
import { jsonGenerate } from "../utils/helper.js";


export const GetWords =async (req,res) => {
  try {
    const list = await Dictionary.words.find();
    res.send(list);
    return res.json(jsonGenerate(StatusCode.SUCCESS,"Word list is available",list));
  } catch (error) {
    return res.json(jsonGenerate(StatusCode.UNPROCESSABLE_ENTRY,"No list available",null))
  }
}

