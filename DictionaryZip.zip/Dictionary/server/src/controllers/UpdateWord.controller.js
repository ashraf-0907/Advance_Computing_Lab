import { StatusCode } from "../utils/constants.js";
import { jsonGenerate } from "../utils/helper.js";
import Word from "../models/word.js"


const Update = async (req, res) =>{
    // const error=validationResult(req);
    const {word , meaning } = req.body;
    console.log(word,meaning);
    const existWord =await Word.findOne({word:word});
    console.log(existWord);
    if(existWord)
    {
        try {
            const result= await Word.updateOne({word:word},{
                meaning:meaning,
            })
            res.json(jsonGenerate(StatusCode.SUCCESS,"Word Updated Successfully",result))
        } catch (error) {
            console.log(error);
        }
        return ;
    }
    else{
        res.json(jsonGenerate(StatusCode.UNPROCESSABLE_ENTRY,"Word does Not exist",null));
    }

    
}

export default Update;
