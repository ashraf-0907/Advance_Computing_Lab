import Header from './components/partials/Header.jsx';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from "./components/Home.jsx"
import AddWord from './components/AddWord.jsx';
import  RemoveWord  from './components/RemoveWord.jsx';
import UpdateWord from '../src/components/UpdateWord.jsx';


function App() {

  

  return (
    <div className="App">
      <BrowserRouter>
      <Header/>
      <Routes>
        <Route path='/' element={<Home/>}></Route>
        <Route path='/addWord' element={<AddWord/>}></Route>
        <Route path='/delete' element={<RemoveWord/>}></Route>
        <Route path='/update' element={<UpdateWord/>}></Route>
      </Routes>
      </BrowserRouter>
  
    </div>
  );
}

export default App;
