import React from "react";
import { useState } from "react";
import { searchWord } from "../services/api.js";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function SearchWord() {
  const [form, setForm] = useState();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    const result = await searchWord(form);

    if (result.status === 200) {
      if (result.data.status === 200) {
        toast(result.data.message);
        document.getElementById('word').value='';
        document.getElementById('word1').value=result.data.data.word;
        document.getElementById('meaning').value=result.data.data.meaning;

        return;
      }

      if (
        result.data === null ||
        result.data.word === null ||
        result.data.meaning === null
      ) {
        toast("Fill entries properly");
        return;
      }


      if (result.data.status === 202) {
        toast(result.data.message);
        return;
      }
    }
  };

  return (
    <div className="container con1">
      <ToastContainer />
      <div className="row justify-content-center mt-4 flex-d">
        <div
          className="col-lg-5 card border-primary mt-4"
          style={{
            background:"linear-gradient(90deg, rgba(20,108,220,1) 35%, rgba(20,220,154,1) 74%)",
            color: "white",
          }}
        >
          <div className="card-body">
            <h4 className="card-title">Search Word</h4>
            <div className="form-group" style={{ display: "flex",justifyContent:"space-between",alignItems:"center", padding:"4px"}}>
              <input
                type="text"
                onChange={handleChange}
                name="word"
                className="form-control"
                id="word"
                aria-describedby="errorHelper"
                placeholder="Enter word"
                style={{height:"56px"}}
              />
               <div className="form-group">
              <div className="form-group" style={{paddingLeft:"8px",}}>
                <label className="form-label mt-4"></label>
                <button
                  type="button"
                  onClick={handleSubmit}
                  class="btn btn-primary"
                >
                  Search
                </button>
              </div>
            </div>
            </div>
            <div className="form-group">
              <label className="form-label mt-4">Word</label>
              <input
                type="text"
                onChange={handleChange}
                name="word1"
                className="form-control"
                id="word1"
                readOnly
              />
            </div>
            <div className="form-group">
              <label className="form-label mt-4">Meaning</label>
              <input
                type="text"
                onChange={handleChange}
                name="meaning"
                className="form-control"
                id="meaning"
                readOnly
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SearchWord;
