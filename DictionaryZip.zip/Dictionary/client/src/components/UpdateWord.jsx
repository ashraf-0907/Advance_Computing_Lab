import React from "react";
import { useState } from "react";
import { updateWord } from "../services/api.js";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


function UpdateWord() {
  const [form, setForm] = useState({
    word: null,
    meaning: null,
  });




  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit=async()=>{

    const result= await updateWord(form);
    console.log('form',result);
    document.getElementById('word').value='';
    document.getElementById("meaning").value='';
     
    if(result.status===200){
        if(result.data.status===200)
        {
            toast(result.data.message);
            //  navigation("/")
            return;
        }


        if (result.data.status===202)
        {
            toast(result.data.message);
            return;
        }
    }
    

  }

  return (
    <div className="container">
        <ToastContainer/>
      <div className="row justify-content-center mt-4">
        <div
          className="col-lg-5 card border-primary mt-4"
          style={{
            background: "linear-gradient(90deg, rgba(20,108,220,1) 35%, rgba(20,220,154,1) 74%)",
            color: "white",
          }}
        >
          <div className="card-body">
            <h4 className="card-title">Update Word</h4>
            <div className="form-group">
              <label className="form-label mt-4">Word</label>
              <input
                type="text"
                onChange={handleChange}
                name="word"
                className="form-control"
                id="word"
                aria-describedby="errorHelper"
                placeholder="Enter word"
              />
            </div>
            <div className="form-group">
              <label className="form-label mt-4">Meaning</label>
              <input
                type="text"
                onChange={handleChange}
                name='meaning'
                className="form-control"
                id="meaning"
                placeholder="Enter meaning"
              />
            </div>
            <div className="form-group">
            <div className="form-group" style={{paddingTop
                :"24px"}}>
            <label className="form-label mt-4"></label>
            <button type="button" onClick={handleSubmit}  class="btn btn-primary">Submit</button>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UpdateWord;