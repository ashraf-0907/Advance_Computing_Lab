import axios from 'axios';
import { AddWord,deleteA,update, search } from './apiConstants.js';



export const addWord= async (data)=>{
    return axios.post(AddWord,data)
}

export const deleteWord= async (data)=>{
    return axios.post(deleteA,data);
}

export const updateWord= async (data)=>{
    return axios.post(update,data);
}

export const searchWord= async (data)=>{
    return axios.post(search,data);
}
