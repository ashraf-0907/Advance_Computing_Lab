import { API_URL } from "../config.js";


export const AddWord=`${API_URL}/api/addWord`;
export const deleteA=`${API_URL}/api/delete`;
export const update=`${API_URL}/api/update`;
export const search=`${API_URL}/api/home`;